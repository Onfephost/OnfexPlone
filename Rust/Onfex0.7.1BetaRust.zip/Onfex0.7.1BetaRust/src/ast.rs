// ast.rs
use crate::builtins::*;
use crate::libs::libStrct::Library;
#[derive(Debug, Clone)]
pub struct ExprNode {
    pub expr: Box<Expr>,
    pub line: usize,
    pub col: usize,
}

impl ExprNode {
    pub fn new(e: Expr, l: usize, c: usize) -> Self {
        Self { expr: Box::new(e), line: l, col: c }
    }
}

#[derive(Debug, Clone)]
pub enum Expr {
    Int(i64),
    Float(f64),
    Str(String),
    Bool(bool),
    Lib(Box<Library>),
    List(String, Vec<ExprNode>),
    Dict(String, Vec<(ExprNode, ExprNode)>),
    LibList(String, String, Vec<ExprNode>),
    LibDict(String, String, Vec<(ExprNode, ExprNode)>),
    Void,
    ArrayDt(Box<Array>),
    BufferDt(Box<Buffer>),
    Variable(String),
    Call(Box<Expr>, Vec<Expr>),
    LibVariable(String,String),
    ModVariable(String,String),
    FuncInht(Frounct),
    Ref(usize),
    Deref(Box<Expr>),
    AddressOf(String),
}

#[derive(Debug, Clone)]
pub enum TypeKind {
    Int,
    Float,
    Str,
    Lib,
    Bool,
    Void,
    Ref,
    ArrayT,
    BufferT,
    FuncInht,
}

impl TypeKind {
    pub fn from_string(name: &str) -> Option<Self> {
        match name {
            "intg" => Some(TypeKind::Int),
            "flotg" => Some(TypeKind::Float),
            "sterg" => Some(TypeKind::Str),
            "nophe" => Some(TypeKind::Void),
            "booltg" => Some(TypeKind::Bool),
            _ => None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct Param {
    pub name: String,
    pub kind: TypeKind,
    pub vararg:bool,
}

#[derive(Debug, Clone)]
pub struct Frounct {
    pub params: Vec<Param>,
    pub body: Vec<StmtNode>,
}

impl Frounct {
    pub fn new(p: Vec<Param>, b: Vec<StmtNode>) -> Self {
        Self { params: p, body: b }
    }
}

#[derive(Debug, Clone)]
pub struct Type {
    pub kind: TypeKind,
    pub value: Expr,
    pub ptr: Option<usize>,
}

impl Type {
    pub fn newVoid() -> Self {
        Self { value: Expr::Void, kind: TypeKind::Void, ptr: None }
    }
    pub fn new(b: TypeKind, a: Expr) -> Self {
        Self { kind: b, value: a, ptr: None }
    }
    pub fn __out__(&self) -> String {
        match &self.value {
            Expr::Int(x) => x.to_string(),
            Expr::Float(x) => x.to_string(),
            Expr::Str(x) => format!("\"{}\"", x),
            Expr::Bool(x) => {
                if *x { "trunth".to_string() } else { "frunth".to_string() }
            }
            Expr::Void => "noph".to_string(),
            Expr::ArrayDt(a) => (a.base.outFn)(&a.items),
            Expr::BufferDt(a) => (a.base.outFn)(&a.mapp),
            Expr::Variable(x) => x.clone(),
            Expr::FuncInht(_) => "<func>".to_string(),
            Expr::Ref(a) => format!("<repherfal:&{}>", a),
            Expr::AddressOf(a) => format!("&{}", a),
            Expr::Deref(_) => "<keonreph>".to_string(),
            _ => "<METHAVEOT>".to_string(),
        }
    }

    pub fn __onfex_eval__(&self) -> Expr {
        self.value.clone()
    }
}

#[derive(Debug, Clone)]
pub struct StmtNode {
    pub stmt: Stmt,
    pub line: usize,
    pub col: usize,
}

impl StmtNode {
    pub fn new(e: Stmt, l: usize, c: usize) -> Self {
        Self { stmt: e, line: l, col: c }
    }
}

#[derive(Debug, Clone)]
pub enum Stmt {
    ExprNode(ExprNode),
    Assign(String, ExprNode),
    ReAssign(String, ExprNode),
    Return(Option<ExprNode>),
    Import(String),
    Mod(String),
    Mehen(Vec<StmtNode>),
    FuncCre(String, Vec<Param>, Vec<StmtNode>, TypeKind),
    TypeLib(String,String),
    TypeMod(String,String),
    IfElse(Box<StmtNode>,Vec<StmtNode>,Option<Vec<StmtNode>>),
}