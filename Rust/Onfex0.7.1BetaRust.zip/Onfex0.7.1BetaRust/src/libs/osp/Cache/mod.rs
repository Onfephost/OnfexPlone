use crate::ast::*;
use crate::builtins::*;
use crate::error::OnfexError;
use std::collections::HashMap;
use std::process::Command;
use crate::ostools::*;

fn system(args:Vec<Type>) -> Result<Type, OnfexError>{
    let cmd = str_get(&args[0].value)?;
    let mut _args = Vec::with_capacity(args[1..].len());
    for i in &args[1..]{
        _args.push(str_get(&i.value)?);
    }
    let res = command(cmd.clone(),_args.clone());
    let expr = Expr::Str(res.clone());
    Ok(Type::new(TypeKind::Str,expr,))
}

fn c_pwd(args:Vec<Type>) -> Result<Type, OnfexError>{
    let res:String = command("pwd".to_string(),vec![]);
    Ok(Type::new(TypeKind::Str,Expr::Str(res)))
}

fn aus(args:Vec<Type>) -> Result<Type,OnfexError>{
    if args.len() == 1{
        let txt:String = str_get(&args[0].value)?;
        let res:String = autocommand(txt);
        Ok(Type::new(TypeKind::Str,Expr::Str(res)))
    }else{
        return Err(OnfexError::runtime("Osp Ern: termifal frounct asp 1 promter beg gephnosfer"));
    }
}

fn chdir(args:Vec<Type>) -> Result<Type,OnfexError>{
    if args.len() == 1{
        let txt:String = str_get(&args[0].value)?;
        let res:String = autocommand(format!("cd {}",txt));
        Ok(Type::new(TypeKind::Str,Expr::Str(res)))
    }else{
        return Err(OnfexError::runtime("Osp Ern: cg frounct asp 1 promter beg gephnosfer"));
    }
}
//Tools
fn str_get(x:&Expr) -> Result<String, OnfexError>{
    match x{
        Expr::Str(s)=>{Ok(s.clone())},
        _ => Err(OnfexError::runtime("Ops:sterge esp wraithnosan")),
    }
}

pub fn load_funcs() -> HashMap<String, fn(Vec<Type>) -> Result<Type, OnfexError>>{
    let mut funcs = HashMap::new();
    funcs.insert("systess".to_string(), system as fn(Vec<Type>) -> Result<Type, OnfexError>);
    funcs.insert("termifal".to_string(), aus as fn(Vec<Type>) -> Result<Type, OnfexError>);
    funcs.insert("kernevGrosser".to_string(), c_pwd as fn(Vec<Type>) -> Result<Type, OnfexError>);
    funcs.insert("cg".to_string(), chdir as fn(Vec<Type>) -> Result<Type, OnfexError>);
    funcs
}

pub fn load_vars() -> HashMap<String,Type>{
    let mut vars = HashMap::new();
    let version = "0.5.1".to_string();
    vars.insert("verzen".to_string(), Type::new(TypeKind::Str,Expr::Str(version.clone())));
    vars
}
