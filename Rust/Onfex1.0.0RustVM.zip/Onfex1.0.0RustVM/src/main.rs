mod token;
mod lexer;
mod ast;
mod parser;
mod interpreter;
mod bytecode;
mod compiler;
mod vm;
mod environment;
mod libs;
mod runtime;
mod builtinsdata;
mod error;
mod builtins;
mod document;
mod ostools;

use lexer::Lexer;
use parser::Parser;
use interpreter::Interpreter;
use error::OnfexError;
use std::fs;
use std::env;
use document::OnfexPloneDoph;
type OPD = OnfexPloneDoph;

fn main() {
    let args: Vec<String> = env::args().collect();
    let use_bytecode = args.iter().any(|a| a == "--bytecode" || a == "-b");

    // RustCode IDE'nin GUI "Run" tuşu argüman geçiremediği için, argüman
    // verilmediğinde eski sabit-kodlu davranış aynen korunur. Terminalden
    // `cargo run -- <path> <name> [--bytecode]` ile de çalıştırılabilir.
    let positional: Vec<String> = args
        .iter()
        .skip(1)
        .filter(|a| !a.starts_with("--") && a.as_str() != "-b")
        .cloned()
        .collect();
    let (path, name) = if positional.len() >= 2 {
        (positional[0].clone(), positional[1].clone())
    } else {
        (
            "/storage/emulated/0/OnfexPlone/Rust/Onfex1.0.0RustVM/src".to_string(),
            "strouct_demo.onfex".to_string(),
        )
    };

    let prog = OPD::new(path, name, false);
    if true {
        prog.run_bytecode();
    } else {
        prog.run();
    }
}
