mod token;
mod lexer;
mod ast;
mod parser;
mod interpreter;
mod environment;
mod libs;
mod runtime;
mod builtinsdata;
mod error;
mod builtins;
mod document;
mod ostools;

use lexer::Lexer;
use parser::Parser;
use interpreter::Interpreter;
use error::OnfexError;
use std::fs;
use document::OnfexPloneDoph;
type OPD = OnfexPloneDoph;

fn main() {
    let path = "/storage/emulated/0/OnfexPlone/Rust/Onfex0.7.0BetaRust/src".to_string();
    let name = "test.onfex".to_string();
    let prog = OPD::new(path.clone(),name.clone(),false);
    OPD::freerun(path.clone(),name.clone());
}
