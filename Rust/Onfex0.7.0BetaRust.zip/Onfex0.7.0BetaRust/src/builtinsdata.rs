// builtinsdata.rs

use crate::ast::*;
use crate::builtins::*;
use crate::error::OnfexError;
use std::io::{self, Write};
use std::collections::HashMap;

pub fn pr(args: Vec<Type>) -> Result<Type, OnfexError> {
    if args.len() == 1 {
        let a = &args[0];
        if matches!(a.value, Expr::Str(_)) {
            let res = a.__out__();
            let ln = res.len();
            print!("{}\n", &res[1..ln - 1]);
        } else {
            print!("{}\n", a.__out__());
        }
    } else {
        let mut res = String::new();
        for a in &args {
            if matches!(a.value, Expr::Str(_)) {
                let rest = a.__out__();
                let ln = rest.len();
                res.push_str(&rest[1..ln - 1]);
            } else {
                res.push_str(&a.__out__());
            }
            res.push(' ');
        }
        res.push('\n');
        print!("{}", res);
    }
    io::stdout()
        .flush()
        .map_err(|e| OnfexError::Runtime { message: format!("failed to flush stdout: {}", e) })?;
    Ok(Type::newVoid())
}

pub fn ask(args: Vec<Type>) -> Result<Type, OnfexError> {
    let mut res = String::new();
    let text = match args.get(0).map(|a| &a.value) {
        Some(Expr::Str(x)) => x.clone(),
        _ => {
            return Err(OnfexError::Runtime {
                message: "morfenlnos expects a single string argument".to_string(),
            });
        }
    };
    print!("{text}");
    io::stdout()
        .flush()
        .map_err(|e| OnfexError::Runtime { message: format!("failed to flush stdout: {}", e) })?;
    io::stdin()
        .read_line(&mut res)
        .map_err(|e| OnfexError::Runtime { message: format!("failed to read input: {}", e) })?;
    Ok(Type::new(TypeKind::Str, Expr::Str(res.trim().to_string())))
}

// VECTOR OUT
pub fn vector_out(v: &Vec<Type>) -> String {
    let mut vals = String::new();
    for i in v {
        vals.push_str(&format!("{} | ", i.__out__()));
    }
    if vals.len() >= 3 {
        vals.truncate(vals.len() - 3);
    }
    format!("<Vektöre [ {} ]>", vals)
}

// MAP OUT
pub fn map_out(v: &Vec<(Type, Type)>) -> String {
    let mut vals = String::new();
    for (k, val) in v {
        vals.push_str(&format!("{} : {}, ", k.__out__(), val.__out__()));
    }
    if vals.len() >= 2 {
        vals.truncate(vals.len() - 2);
    }
    format!("<Map {{{}}}>", vals)
}

// CREATE ARRAY TYPES
pub fn create_array_types() -> HashMap<String, ArrayType> {
    let mut arrs = HashMap::new();
    // vektöre
    arrs.insert(
        "vektöre".to_string(),
        ArrayType::new("vektöre".to_string(), vector_out),
    );
    arrs
}

// CREATE BUFFER TYPES
pub fn create_buffer_types() -> HashMap<String, BufferType> {
    let mut buffs = HashMap::new();
    buffs.insert(
        "mappe".to_string(),
        BufferType::new("mappe".to_string(), map_out),
    );
    buffs
}
