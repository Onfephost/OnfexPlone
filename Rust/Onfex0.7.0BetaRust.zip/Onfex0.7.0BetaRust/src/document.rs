use crate::ast;
use crate::environment::*;
use crate::runtime;
use crate::builtinsdata;
use crate::builtins;
use crate::token::*;
use crate::lexer::Lexer;
use crate::parser::Parser;
use crate::interpreter::Interpreter;
use crate::error::OnfexError;
use std::fs;
use std::cell::RefCell;

pub struct OnfexPloneDoph{
    version:String,
    path:String,
    name:String,
    isImport:bool,
    code:String,
}

impl OnfexPloneDoph{
    pub fn new(path:String,name:String,isImport:bool)->Self{
        let code:Result<String,OnfexError> = fs::read_to_string(format!("{}/{}",path,name))
            .map_err(|e| OnfexError::Runtime {
                message: format!("Grosser Opernal Ern: ern oft rendnen: {}", e),
            }
        );
        Self{
            version:"0.7.0".to_string(),
            path,
            name,
            isImport,
            code:code.unwrap()
        }
    }
    
    pub fn verifyVersion(&self,v:String) -> bool{
        return self.version==v;
    }
    
    pub fn run(&self) -> Option<RefCell<Environment>>{
        let lexer = Lexer::new(self.code.clone());
        let program = match Parser::new(lexer).and_then(|mut parser| parser.parse()) {
            Ok(p) => p,
            Err(e) => {
                println!("{}", e);
                return None;
            }
        };
        let interpreter = Interpreter::new(self.path.clone());
        *interpreter.Import.borrow_mut() = self.isImport.clone();
        if self.isImport.clone(){
            match interpreter.run(program) {
                Ok(_) => Some(interpreter.env),
                Err(e) => {
                    println!("{}", e);
                    return None;
                }
            }
        }else{
            match interpreter.run(program) {
                Ok(_) => return None,
                Err(e) => {
                println!("{}", e);
                    return None;
                }
            }
        }
    }
    pub fn freerun(path:String,name:String) -> i8{
        //This not supporting multi document inserted projects
        let code:Result<String,OnfexError> = fs::read_to_string(format!("{}/{}",path,name)).map_err(|e| OnfexError::Runtime {
            message: format!("Grosser Opernal Ern: ern oft rendnen: {}", e),
        });
        let lexer = Lexer::new(code.unwrap().clone());
        let program = match Parser::new(lexer).and_then(|mut parser| parser.parse()) {
            Ok(p) => p,
            Err(e) => {
                println!("{}", e);
                return 1;
            }
        };
        let interpreter = Interpreter::new("".to_string());
        *interpreter.selfAccess.borrow_mut() = true;
        let selfAccess = interpreter.selfAccess.borrow().clone();
        match interpreter.run(program) {
                Ok(_) => {
                    return 0;
                },
                Err(e) => {
                    println!("{}", e);
                    return 1;
                }
            }
    }
}