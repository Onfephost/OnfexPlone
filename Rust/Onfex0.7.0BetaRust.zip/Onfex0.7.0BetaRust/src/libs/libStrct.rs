use std::collections::HashMap;
use crate::ast::*;
use crate::builtins::*;
use crate::error::OnfexError;
#[derive(Debug,Clone)]
pub struct Library {
    pub name: String,
    pub funcs: HashMap<String, fn(Vec<Type>) -> Result<Type, OnfexError>>,
    pub vars: HashMap<String,Type>,
    pub array_types: HashMap<String, ArrayType>,
    pub buffer_types: HashMap<String, BufferType>,
    pub mono_types: HashMap<String, MonoType>,
}

impl Library {
    pub fn new(n: String,fs: HashMap<String, fn(Vec<Type>) -> Result<Type, OnfexError>>,
    _vars:HashMap<String,Type>,at: HashMap<String, ArrayType>,bt: HashMap<String, BufferType>,mt:HashMap<String, MonoType>) -> Self {
        Self { name: n, funcs: fs,vars:_vars, array_types: at, buffer_types: bt ,mono_types:mt}
    }
}
