// interpreter.rs

use crate::ast::*;
use crate::builtins::*;
use crate::builtinsdata::*;
use crate::environment::Environment;
use crate::error::OnfexError;
use crate::libs::libacs::*;
use crate::libs::libStrct::Library;
use crate::runtime::Flow;
use std::cell::RefCell;
use std::collections::HashMap;
use crate::document::OnfexPloneDoph;
type OPD = OnfexPloneDoph;


pub struct Interpreter {
    pub builtins: HashMap<String, FUNC>,
    pub array_types: HashMap<String, ArrayType>,
    pub buffer_types: HashMap<String, BufferType>,
    pub mono_types: HashMap<String, MonoType>,
    pub env: RefCell<Environment>,
    pub libs: RefCell<HashMap<String, Library>>,
    pub ptr: RefCell<usize>,
    pub mods: RefCell<HashMap<String,RefCell<Environment>>>,
    pub selfAccess:RefCell<bool>,
    pub Import:RefCell<bool>,
    pub path: String,
}

impl Interpreter {
    // new
    pub fn new(path:String) -> Self {
        Self {
            builtins: create_builtins_funcs(),
            array_types: create_array_types(),
            buffer_types: create_buffer_types(),
            mono_types: HashMap::new(),
            env: RefCell::new(Environment::new()),
            libs: RefCell::new(HashMap::new()),
            ptr: RefCell::new(1),
            mods:RefCell::new(HashMap::new()),
            selfAccess :RefCell::new(false),
            Import :RefCell::new(false),
            path,
        }
    }

    // run
    pub fn run(&self, program: Vec<StmtNode>) -> Result<(), OnfexError> {
        for stmt in &program {
            match self.exec(stmt)? {
                Flow::Normal(_) => {}
                Flow::Empty => {}
                // a `erutnos` at the top level simply stops the program
                Flow::Return(_) => return Ok(()),
            }
        }
        Ok(())
    }

    // exec
    fn exec(&self, stmt: &StmtNode) -> Result<Flow, OnfexError> {
        match &stmt.stmt {
            // expr
            Stmt::ExprNode(expr) => {
                let v = self.eval(&expr.expr)?;
                Ok(Flow::Normal(v))
            }
            // assign
            Stmt::Assign(name, expr) => {
                let adr = *self.ptr.borrow();
                let mut value = self.eval(&expr.expr)?;
                value.ptr = Some(adr);
                self.env.borrow_mut().names.insert(name.clone(), adr);
                self.env.borrow_mut().heap.insert(adr, value);
                self.inc_ptr();
                Ok(Flow::Normal(Type::newVoid()))
            }
            // reassign
            Stmt::ReAssign(name, expr) => {
                let adr = self.lookup_address(&self.env.borrow(), name)?;
                let mut value = self.eval(&expr.expr)?;
                value.ptr = Some(adr);
                self.env.borrow_mut().heap.insert(adr, value);
                Ok(Flow::Normal(Type::newVoid()))
            }
            // import
            Stmt::Import(name) => {
                let lib = loadLib(name)?;
                self.libs.borrow_mut().insert(name.clone(), lib);
                Ok(Flow::Normal(Type::newVoid()))
            }
            Stmt::Mod(nam) => {
                if *self.selfAccess.borrow(){
                    let name = nam.clone().replace("..",self.path.clone().as_str());
                    let  mut v:Vec<String> = name.split("/").map(|x| x.to_string()).collect();
                    let docname = v.clone()[v.clone().len()-1].clone();
                    v.remove(v.clone().len()-1);
                    let mut docpath = String::new();
                    for i in v.clone(){
                        docpath.push_str(&("/".to_owned()+i.as_str()));
                    }
                    let doc = OPD::new(docpath,docname.clone(),true);
                    let res = doc.run().unwrap_or(Environment::new().into());
                    self.mods.borrow_mut().insert(docname,res);
                    Ok(Flow::Normal(Type::newVoid()))
                }else{
                    Err(OnfexError::Runtime{message:"Mot Ern: Mot Freat keonaertenosfer".to_string()})
                }
            }
            // return
            Stmt::Return(expr) => {
                let value = match expr {
                    Some(e) => self.eval(&e.expr)?,
                    None => Type::newVoid(),
                };
                Ok(Flow::Return(value))
            }
            Stmt::TypeLib(new,old) => {
                let mut map = self.libs.borrow_mut();
                if let Some(value) = map.remove(old.into()) {
                    map.insert(new.clone(), value);
                    return Ok(Flow::Normal(Type::newVoid()));
                }else{
                    return Err(
                        OnfexError::Runtime{message:format!("WrossnosLrib Ern: keoninferins lrib {}",old)}
                    );
                }
            }
            // mehen
            Stmt::Mehen(body) => {
                self.enter_scope();
                let mut out = Type::newVoid();
                for s in body {
                    match self.exec(s) {
                        Ok(Flow::Normal(v)) => {
                            out = v;
                        }
                        Ok(Flow::Empty) => {}
                        Ok(Flow::Return(v)) => {
                            self.exit_scope();
                            return Ok(Flow::Return(v));
                        }
                        Err(e) => {
                            self.exit_scope();
                            return Err(e);
                        }
                    }
                }
                self.exit_scope();
                Ok(Flow::Normal(out))
            }
            // function create
            Stmt::FuncCre(name, params, body, _) => {
                let func = Frounct::new(params.clone(), body.clone());
                let adr = *self.ptr.borrow();
                self.env.borrow_mut().names.insert(name.clone(), adr);
                self.env
                    .borrow_mut()
                    .heap
                    .insert(adr, Type::new(TypeKind::FuncInht, Expr::FuncInht(func)));
                self.inc_ptr();
                Ok(Flow::Normal(Type::newVoid()))
            }
            _ => {Ok(Flow::Empty)}
        }
    }

    // eval
    fn eval(&self, expr: &Expr) -> Result<Type, OnfexError> {
        match expr {
            Expr::Int(x) => Ok(Type::new(TypeKind::Int, Expr::Int(*x))),
            Expr::Float(x) => Ok(Type::new(TypeKind::Float, Expr::Float(*x))),
            Expr::Str(x) => Ok(Type::new(TypeKind::Str, Expr::Str(x.clone()))),
            Expr::Bool(x) => Ok(Type::new(TypeKind::Bool, Expr::Bool(*x))),
            Expr::Void => Ok(Type::newVoid()),
            Expr::Variable(name) => self.get_var(name),
            Expr::Deref(inner) => {
                let r = self.eval(inner)?;
                match r.value {
                    Expr::Ref(adr) => {
                        let env = self.env.borrow();
                        self.load_from_heap(&env, adr)
                    }
                    _ => Err(OnfexError::Runtime {
                        message: "cannot dereference a non-reference value".to_string(),
                    }),
                }
            }
            // function inherit
            Expr::FuncInht(f) => Ok(Type::new(TypeKind::FuncInht, Expr::FuncInht(f.clone()))),
            // array runtime
            Expr::ArrayDt(arr) => Ok(Type::new(TypeKind::ArrayT, Expr::ArrayDt(arr.clone()))),
            // buffer runtime
            Expr::BufferDt(buf) => Ok(Type::new(TypeKind::BufferT, Expr::BufferDt(buf.clone()))),
            // list
            Expr::List(type_name, items) => {
                let mut vals = Vec::with_capacity(items.len());
                for item in items {
                    vals.push(self.eval(&item.expr)?);
                }
                let tp = self.array_types.get(type_name).cloned().ok_or_else(|| {
                    OnfexError::Runtime { message: format!("undefined array type '{}'", type_name) }
                })?;
                Ok(Type::new(TypeKind::ArrayT, Expr::ArrayDt(Box::new(Array::new(vals, tp)))))
            }
            // dict
            Expr::Dict(type_name, items) => {
                let mut vals = Vec::with_capacity(items.len());
                for (k, v) in items {
                    vals.push((self.eval(&k.expr)?, self.eval(&v.expr)?));
                }
                let tp = self.buffer_types.get(type_name).cloned().ok_or_else(|| {
                    OnfexError::Runtime { message: format!("undefined buffer type '{}'", type_name) }
                })?;
                Ok(Type::new(TypeKind::BufferT, Expr::BufferDt(Box::new(Buffer::new(vals, tp)))))
            }
            // call
            Expr::Call(name, args) => {
                let mut values = Vec::with_capacity(args.len());
                for a in args {
                    values.push(self.eval(a)?);
                }
                let nam:String = match *name.clone().expr{
                    Expr::Variable(x) => {x.clone()}
                    _ => "undefined".to_string(),
                };
                match *name.clone().expr{
                    Expr::Variable(x) => {
                        // builtin
                        if let Some(func) = self.builtins.get(&x) {
                            return func.run(values);
                        }
                    },
                    _ =>(),
                }
                // user func
                let f = self.eval(&*name.expr)?;
                if let Expr::FuncInht(func) = f.value {
                    return self.run_func(func, values);
                }
                Err(OnfexError::Runtime { message: format!("'{}' is not a function",nam) })
            }
            Expr::AddressOf(name) => {
                let adr = self.lookup_address(&self.env.borrow(), name)?;
                Ok(Type::new(TypeKind::Ref, Expr::Ref(adr)))
            }
            Expr::Ref(s) => Ok(Type::new(TypeKind::Ref, Expr::Ref(*s))),
            // lib call
            Expr::LibCall(lib, name, args) => {
                let mut values = Vec::with_capacity(args.len());
                for a in args {
                    values.push(self.eval(a)?);
                }
                let libs = self.libs.borrow();
                let l = libs.get(lib).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined library or modul2 '{}'", lib),
                })?;
                let func = l.funcs.get(name).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined function '{}->{}'", lib, name),
                })?;
                func(values)
            }
            Expr::LibVariable(lib, name) => {
                let libs = self.libs.borrow();
                let l = libs.get(lib).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined library '{}'", lib),
                })?;
                let var = l.vars.get(name).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined var '{}->{}'", lib, name),
                })?;
                Ok(var.clone())
            }
            // lib list
            Expr::LibList(lib, name, items) => {
                self.inc_ptr();
                let mut values = Vec::with_capacity(items.len());
                for item in items {
                    values.push(self.eval(&item.expr)?);
                }
                let libs = self.libs.borrow();
                let library = libs.get(lib).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined library '{}'", lib),
                })?;
                let arr_type = library
                    .array_types
                    .get(name)
                    .ok_or_else(|| OnfexError::Runtime {
                        message: format!("undefined array type '{}::{}'", lib, name),
                    })?
                    .clone();
                Ok(Type::new(TypeKind::ArrayT, Expr::ArrayDt(Box::new(Array::new(values, arr_type)))))
            }
            Expr::LibDict(lib, name, items) => {
                let mut values = Vec::with_capacity(items.len());
                for (k, v) in items {
                    values.push((self.eval(&k.expr)?, self.eval(&v.expr)?));
                }
                let libs = self.libs.borrow();
                let library = libs.get(lib).ok_or_else(|| OnfexError::Runtime {
                    message: format!("undefined library '{}'", lib),
                })?;
                let buf_type = library
                    .buffer_types
                    .get(name)
                    .ok_or_else(|| OnfexError::Runtime {
                        message: format!("undefined buffer type '{}::{}'", lib, name),
                    })?
                    .clone();
                Ok(Type::new(TypeKind::BufferT, Expr::BufferDt(Box::new(Buffer::new(values, buf_type)))))
            }
            Expr::Lib(l) => {
                let res = Expr::Lib(l.clone());
                Ok(Type::new(TypeKind::Lib,res))
            }
            _ => {Ok(Type::newVoid())}
        }
    }

    fn inc_ptr(&self) {
        *self.ptr.borrow_mut() += 1;
    }

    fn load_from_heap(&self, env: &Environment, adr: usize) -> Result<Type, OnfexError> {
        if let Some(v) = env.heap.get(&adr) {
            return Ok(v.clone());
        }
        if let Some(parent) = &env.parent {
            return self.load_from_heap(parent, adr);
        }
        Err(OnfexError::Runtime { message: format!("invalid address {}", adr) })
    }

    fn lookup_address(&self, env: &Environment, name: &str) -> Result<usize, OnfexError> {
        if let Some(adr) = env.names.get(name) {
            return Ok(*adr);
        }
        if let Some(p) = &env.parent {
            return self.lookup_address(p, name);
        }
        Err(OnfexError::Runtime { message: format!("variable '{}' not found", name) })
    }

    // run user function
    fn run_func(&self, func: Frounct, args: Vec<Type>) -> Result<Type, OnfexError> {
        self.enter_scope();
        for (par, arg) in func.params.iter().zip(args) {
            let adr = *self.ptr.borrow();
            self.env.borrow_mut().names.insert(par.name.clone(), adr);
            self.env.borrow_mut().heap.insert(adr, arg);
            self.inc_ptr();
        }
        let mut out = Type::newVoid();
        for s in &func.body {
            match self.exec(s) {
                Ok(Flow::Normal(v)) => {
                    out = v;
                }
                Ok(Flow::Empty) => {}
                Ok(Flow::Return(v)) => {
                    self.exit_scope();
                    return Ok(v);
                }
                Err(e) => {
                    self.exit_scope();
                    return Err(e);
                }
            }
        }
        self.exit_scope();
        Ok(out)
    }

    // variable
    fn get_var(&self, name: &str) -> Result<Type, OnfexError> {
        let env = self.env.borrow();
        self.lookup(&env, name)
    }

    fn lookup(&self, env: &Environment, name: &str) -> Result<Type, OnfexError> {
        if let Some(adr) = env.names.get(name) {
            if let Some(v) = env.heap.get(adr) {
                return Ok(v.clone());
            }
        }
        if let Some(p) = &env.parent {
            return self.lookup(p, name);
        }
        Err(OnfexError::Runtime { message: format!("variable '{}' not found", name) })
    }

    // scope
    fn enter_scope(&self) {
        let current = self.env.replace(Environment::new());
        let child = Environment::child(current);
        self.env.replace(child);
    }
    fn exit_scope(&self) {
        let current = self.env.replace(Environment::new());
        if let Some(p) = current.parent {
            self.env.replace(*p);
        }
    }
}
