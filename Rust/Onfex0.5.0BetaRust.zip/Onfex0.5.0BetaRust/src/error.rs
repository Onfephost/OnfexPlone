use std::fmt;

#[derive(Debug,Clone)]
pub enum OnfexError {
    Lexer{
        message:String,
        line:usize,
        col:usize,
    },

    Parser{
        message:String,
        line:usize,
        col:usize,
    },

    Runtime{
        message:String,
    },
}


impl fmt::Display for OnfexError {

    fn fmt(&self,f:&mut fmt::Formatter)->fmt::Result{
        match self {
            OnfexError::Lexer{message,line,col}=>{
                write!(f,"[Lexer Error] {} at {}:{}",message,line,col)}

            OnfexError::Parser{message,line,col}=>{
                write!(
                    f,
                    "[Parser Error] {} at {}:{}",
                    message,
                    line,
                    col
                )
            }
            
            OnfexError::Runtime{message}=>{
                write!(f,"[Runtime Error] {}",message)
            }
        }
    }
}