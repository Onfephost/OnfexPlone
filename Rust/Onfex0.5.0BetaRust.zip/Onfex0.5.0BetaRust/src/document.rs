
use crate::ast;
use crate::environment::*;
use crate::runtime;
use crate::builtinsdata;
use crate::builtins;
use crate::token::*;
use crate::lexer::Lexer;
use crate::parser::Parser;
use crate::interpreter::Interpreter;
use crate::error::OnfexError;
use std::fs;
use std::cell::RefCell;

pub struct OnfexPloneDoph{
    path:String,
    name:String,
    isImport:bool,
    code:String,
}

impl OnfexPloneDoph{
    pub fn new(path:String,name:String,isImport:bool)->Self{
        let code:Result<String,OnfexError> = fs::read_to_string(format!("{}/{}",path,name)).map_err(|e| OnfexError::Runtime {
            message: format!("failed to read source file: {}", e),
        });
        Self{path, name, isImport,code:code.unwrap()}
    }
    pub fn run(&self) ->Option<RefCell<Environment>>{
        let lexer = Lexer::new(self.code.clone());
        let program = match Parser::new(lexer).and_then(|mut parser| parser.parse()) {
            Ok(p) => p,
            Err(e) => {
                println!("{}", e);
                return None;
            }
        };
        let interpreter = Interpreter::new();
        *interpreter.Import.borrow_mut() = self.isImport.clone();
        if self.isImport.clone(){
            match interpreter.run(program) {
                Ok(_) => Some(interpreter.env),
                Err(e) => {
                println!("{}", e);
                    None
                }
            }
        }else{
            match interpreter.run(program) {
                Ok(_) => None,
                Err(e) => {
                println!("{}", e);
                    None
                }
            }
        }
    }
    pub fn freerun(path:String,name:String) {
        let code:Result<String,OnfexError> = fs::read_to_string(format!("{}/{}",path,name)).map_err(|e| OnfexError::Runtime {
            message: format!("failed to read source file: {}", e),
        });
        let lexer = Lexer::new(code.unwrap().clone());
        let program = match Parser::new(lexer).and_then(|mut parser| parser.parse()) {
            Ok(p) => p,
            Err(e) => {
                println!("{}", e);
                return;
            }
        };
        let interpreter = Interpreter::new();
        *interpreter.selfAccess.borrow_mut() = true;
        match interpreter.run(program) {
                Ok(_) => {},
                Err(e) => {println!("{}", e);}
            }
    }
}

