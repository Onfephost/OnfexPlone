// ==========================
// parser.rs
// ==========================

use crate::ast::*;
use crate::lexer::Lexer;
use crate::token::Token;
use crate::token::TokenKind;
use crate::error::OnfexError;

pub struct Parser {
    lexer: Lexer,
    current: Token,
    next: Token,
}

impl Parser {
    pub fn new(mut lexer: Lexer) -> Result<Self, OnfexError> {
        let current = lexer.next_token()?;
        let next = lexer.next_token()?;
        Ok(Self { lexer, current, next })
    }

    fn advance(&mut self) -> Result<(), OnfexError> {
        self.current = self.next.clone();
        self.next = self.lexer.next_token()?;
        Ok(())
    }

    fn expect(&mut self, tk: TokenKind) -> Result<(), OnfexError> {
        if std::mem::discriminant(&self.current.kind) != std::mem::discriminant(&tk) {
            return Err(OnfexError::Parser {
                message: format!("expected {:?}, got {:?}", tk, self.current.kind),
                line: self.current.line,
                col: self.current.col,
            });
        }
        self.advance()
    }

    fn getCurrent(&self) -> TokenKind {
        self.current.kind.clone()
    }

    fn getCurrentToken(&self) -> Token {
        self.current.clone()
    }

    fn unexpected(&self, expected: &str) -> OnfexError {
        OnfexError::Parser {
            message: format!("expected {}, got {:?}", expected, self.current.kind),
            line: self.current.line,
            col: self.current.col,
        }
    }

    // ====================
    // expr
    // ====================
    fn expr(&mut self) -> Result<Expr, OnfexError> {
        match self.getCurrent() {
            TokenKind::Number(x) => {
                self.advance()?;
                Ok(Expr::Int(x))
            }
            TokenKind::Float(x) => {
                self.advance()?;
                Ok(Expr::Float(x))
            }
            TokenKind::String(x) => {
                self.advance()?;
                Ok(Expr::Str(x))
            }
            TokenKind::Bool(x) => {
                self.advance()?;
                Ok(Expr::Bool(x))
            }
            TokenKind::Void => {
                self.advance()?;
                Ok(Expr::Void)
            }
            TokenKind::LBracket => {
                let node = self.list_expr("vektöre".to_string())?;
                Ok(node.expr)
            }
            TokenKind::LBrace => {
                let node = self.dict_expr("mappe".to_string())?;
                Ok(node.expr)
            }
            // '&' character (address-of)
            TokenKind::And => {
                self.advance()?;
                let n = match self.getCurrent() {
                    TokenKind::Identifier(x) => x,
                    _ => return Err(self.unexpected("identifier after '&'")),
                };
                self.advance()?;
                Ok(Expr::AddressOf(n))
            }
            TokenKind::Star => {
                self.advance()?;
                let inner = self.expr()?;
                Ok(Expr::Deref(Box::new(inner)))
            }
            TokenKind::Identifier(name) => {
                let n = name;
                self.advance()?;
                // function call
                if matches!(self.getCurrent(), TokenKind::LParen) {
                    self.advance()?;
                    let args = self.args()?;
                    self.expect(TokenKind::RParen)?;
                    return Ok(Expr::Call(n, args));
                }
                // n::_
                else if matches!(self.getCurrent(), TokenKind::Colon) {
                    self.advance()?;
                    self.expect(TokenKind::Colon)?;
                    if matches!(self.getCurrent(), TokenKind::LBracket) {
                        let node = self.list_expr(n)?;
                        return Ok(node.expr);
                    }
                    if matches!(self.getCurrent(), TokenKind::LBrace) {
                        let node = self.dict_expr(n)?;
                        return Ok(node.expr);
                    }
                    
                    return Err(self.unexpected("'[' or '{' after '::'"));
                }
                // n!->m
                else if matches!(self.getCurrent(),TokenKind::Clam){
                    self.advance()?;
                    self.expect(TokenKind::Minus)?;
                    self.expect(TokenKind::Gt)?;
                    let n2 = match self.getCurrent() {
                        TokenKind::Identifier(x) => x,
                        _ => return Err(self.unexpected("identifier after '->'")),
                    };
                    if matches!(self.getCurrent(),TokenKind::LParen){
                        self.advance()?;
                        let args = self.args()?;
                        self.expect(TokenKind::RParen)?;
                        return Ok(Expr::ModCall(n, n2, args));
                    }
                    return Ok(Expr::ModVariable(n,n2));
                }
                // n->m
                else if matches!(self.getCurrent(), TokenKind::Minus) {
                    self.advance()?;
                    self.expect(TokenKind::Gt)?;
                    let n2 = match self.getCurrent() {
                        TokenKind::Identifier(x) => x,
                        _ => return Err(self.unexpected("identifier after '->'")),
                    };
                    self.advance()?;
                    if matches!(self.getCurrent(), TokenKind::LParen) {
                        self.advance()?;
                        let args = self.args()?;
                        self.expect(TokenKind::RParen)?;
                        return Ok(Expr::LibCall(n, n2, args));
                    } else if matches!(self.getCurrent(), TokenKind::Colon) {
                        self.advance()?;
                        self.expect(TokenKind::Colon)?;
                        if matches!(self.getCurrent(), TokenKind::LBracket) {
                            let node = self.list_expr(n2)?;
                            let (nm, vl) = match node.expr {
                                Expr::List(x, y) => (x, y),
                                _ => unreachable!("list_expr always returns Expr::List"),
                            };
                            return Ok(Expr::LibList(n, nm, vl));
                        }
                        if matches!(self.getCurrent(), TokenKind::LBrace) {
                            let node = self.dict_expr(n2)?;
                            let (nm, vl) = match node.expr {
                                Expr::Dict(x, y) => (x, y),
                                _ => unreachable!("dict_expr always returns Expr::Dict"),
                            };
                            return Ok(Expr::LibDict(n, nm, vl));
                        }
                        return Err(self.unexpected("'[' or '{' after '::'"));
                    }
                    return Ok(Expr::LibVariable(n,n2));
                }
                Ok(Expr::Variable(n))
            }
            _ => Err(self.unexpected("an expression")),
        }
    }

    fn exprnode(&mut self) -> Result<ExprNode, OnfexError> {
        let tok = self.getCurrentToken();
        let e = self.expr()?;
        Ok(ExprNode::new(e, tok.line, tok.col))
    }

    // list
    fn list_expr(&mut self, auf: String) -> Result<ExprNode, OnfexError> {
        let tok = self.getCurrentToken();
        self.advance()?; // consume '['
        let mut vals = vec![];
        loop {
            if matches!(self.getCurrent(), TokenKind::RBracket) {
                break;
            }
            vals.push(self.exprnode()?);
            if matches!(self.getCurrent(), TokenKind::Comma) {
                self.advance()?;
            } else {
                break;
            }
        }
        self.expect(TokenKind::RBracket)?;
        Ok(ExprNode::new(Expr::List(auf, vals), tok.line, tok.col))
    }

    // dict
    fn dict_expr(&mut self, auf: String) -> Result<ExprNode, OnfexError> {
        let tok = self.getCurrentToken();
        self.advance()?; // consume '{'
        let mut vals = vec![];
        loop {
            if matches!(self.getCurrent(), TokenKind::RBrace) {
                break;
            }
            let key = self.exprnode()?;
            self.expect(TokenKind::Colon)?;
            let val = self.exprnode()?;
            vals.push((key, val));
            if matches!(self.getCurrent(), TokenKind::Comma) {
                self.advance()?;
            } else {
                break;
            }
        }
        self.expect(TokenKind::RBrace)?;
        Ok(ExprNode::new(Expr::Dict(auf, vals), tok.line, tok.col))
    }

    // args
    fn args(&mut self) -> Result<Vec<Expr>, OnfexError> {
        let mut v = vec![];
        if matches!(self.getCurrent(), TokenKind::RParen) {
            return Ok(v);
        }
        loop {
            v.push(self.expr()?);
            if matches!(self.getCurrent(), TokenKind::Comma) {
                self.advance()?;
            } else {
                break;
            }
        }
        Ok(v)
    }

    // params
    fn params(&mut self) -> Result<Vec<Param>, OnfexError> {
        let mut v = vec![];
        if matches!(self.getCurrent(), TokenKind::RParen) {
            return Ok(v);
        }
        loop {
            let name = match self.getCurrent() {
                TokenKind::Identifier(x) => x,
                _ => return Err(self.unexpected("parameter name")),
            };
            self.advance()?;
            self.expect(TokenKind::Colon)?;
            let ty = match self.getCurrent() {
                TokenKind::TyKd(x) => x,
                _ => return Err(self.unexpected("a type")),
            };
            self.advance()?;
            v.push(Param { name, kind: ty });
            if matches!(self.getCurrent(), TokenKind::Comma) {
                self.advance()?;
            } else {
                break;
            }
        }
        Ok(v)
    }

    // import
    fn import_stmt(&mut self) -> Result<StmtNode, OnfexError> {
        let tok = self.getCurrentToken();
        self.advance()?; // consume 'urso'
        let name = match self.getCurrent() {
            TokenKind::Identifier(x) => x,
            _ => return Err(self.unexpected("library name")),
        };
        self.advance()?;
        if matches!(self.getCurrent(), TokenKind::As) {
            self.advance()?;
            let name2 = match self.getCurrent() {
                TokenKind::Identifier(x) => x,
                _ => return Err(self.unexpected("alias name")),
            };
            self.advance()?;
            self.expect(TokenKind::Semi)?;
            return Ok(StmtNode::new(Stmt::ImportAs(name, name2), tok.line, tok.col));
        }
        self.expect(TokenKind::Semi)?;
        Ok(StmtNode::new(Stmt::Import(name), tok.line, tok.col))
    }

    // mehen
    fn mehen(&mut self) -> Result<StmtNode, OnfexError> {
        let tok = self.getCurrentToken();
        self.advance()?;
        self.expect(TokenKind::LParen)?;
        self.expect(TokenKind::RParen)?;
        self.expect(TokenKind::LBrace)?;
        let mut body = vec![];
        while !matches!(self.getCurrent(), TokenKind::RBrace) {
            body.push(self.statement()?);
        }
        self.expect(TokenKind::RBrace)?;
        Ok(StmtNode::new(Stmt::Mehen(body), tok.line, tok.col))
    }

    // function create
    fn fc(&mut self) -> Result<StmtNode, OnfexError> {
        let tok = self.getCurrentToken();
        self.advance()?;
        let name = match self.getCurrent() {
            TokenKind::Identifier(x) => x,
            _ => return Err(self.unexpected("function name")),
        };
        self.advance()?;
        self.expect(TokenKind::LParen)?;
        let pars = self.params()?;
        self.expect(TokenKind::RParen)?;
        self.expect(TokenKind::Minus)?;
        self.expect(TokenKind::Gt)?;
        let out = match self.getCurrent() {
            TokenKind::TyKd(x) => x,
            _ => return Err(self.unexpected("a return type")),
        };
        self.advance()?;
        self.expect(TokenKind::LBrace)?;
        let mut body = vec![];
        while !matches!(self.getCurrent(), TokenKind::RBrace) {
            body.push(self.statement()?);
        }
        self.expect(TokenKind::RBrace)?;
        Ok(StmtNode::new(Stmt::FuncCre(name, pars, body, out), tok.line, tok.col))
    }

    // assign / reassign
    fn assign(&mut self, is_re: bool) -> Result<StmtNode, OnfexError> {
        if !is_re {
            self.advance()?; // consume 'valt'
        }
        let tok = self.getCurrentToken();
        let name = match self.getCurrent() {
            TokenKind::Identifier(x) => x,
            _ => return Err(self.unexpected("variable name")),
        };
        self.advance()?;
        self.expect(TokenKind::Equal)?;
        let val = self.exprnode()?;
        self.expect(TokenKind::Semi)?;
        let stmt = if is_re {
            Stmt::ReAssign(name, val)
        } else {
            Stmt::Assign(name, val)
        };
        Ok(StmtNode::new(stmt, tok.line, tok.col))
    }

    // statement
    fn statement(&mut self) -> Result<StmtNode, OnfexError> {
        match self.getCurrent() {
            TokenKind::Mehen => self.mehen(),
            TokenKind::Urso => self.import_stmt(),
            TokenKind::Func => self.fc(),
            TokenKind::Return => {
                let tok = self.getCurrentToken();
                self.advance()?;
                if matches!(self.getCurrent(), TokenKind::Semi) {
                    self.advance()?;
                    return Ok(StmtNode::new(Stmt::Return(None), tok.line, tok.col));
                }
                let val = self.exprnode()?;
                self.expect(TokenKind::Semi)?;
                Ok(StmtNode::new(Stmt::Return(Some(val)), tok.line, tok.col))
            }
            TokenKind::Valt => self.assign(false),
            TokenKind::Identifier(_) => {
                if matches!(self.next.kind, TokenKind::Equal) {
                    return self.assign(true);
                }
                let e = self.exprnode()?;
                let (line, col) = (e.line, e.col);
                self.expect(TokenKind::Semi)?;
                Ok(StmtNode::new(Stmt::ExprNode(e), line, col))
            }
            _ => {
                let e = self.exprnode()?;
                let (line, col) = (e.line, e.col);
                self.expect(TokenKind::Semi)?;
                Ok(StmtNode::new(Stmt::ExprNode(e), line, col))
            }
        }
    }

    // ====================
    // parse
    // ====================
    pub fn parse(&mut self) -> Result<Vec<StmtNode>, OnfexError> {
        let mut v = vec![];
        while !matches!(self.getCurrent(), TokenKind::EOF) {
            v.push(self.statement()?);
        }
        Ok(v)
    }
}
