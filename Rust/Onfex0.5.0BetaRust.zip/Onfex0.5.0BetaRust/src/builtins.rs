// builtins.rs

use crate::ast::*;
use crate::error::OnfexError;
use std::collections::HashMap;
use std::cell::RefCell;
use crate::environment::*;
// ================= FUNC =================

#[derive(Debug, Clone)]
pub struct FUNC {
    pub func: fn(Vec<Type>) -> Result<Type, OnfexError>,
}

impl FUNC {
    pub fn run(&self, args: Vec<Type>) -> Result<Type, OnfexError> {
        (self.func)(args)
    }
}

#[derive(Debug, Clone)]
pub struct Class {
    pub name : String,
    pub methods : RefCell<HashMap<String,FUNC>>,
    pub fields: RefCell<HashMap<String, Type>>,
    pub inht : Option<Box<Self>>,
}

impl Class {
    pub fn new(name:String ,methods:RefCell<HashMap<String,FUNC>> ,
    fields: RefCell<HashMap<String,Type>>, inht:Option<Box<Self>>) -> Self{
        
        Self{name,methods,fields,inht}
    }
}

#[derive(Debug, Clone)]
pub struct ClassObject {
    pub base : Class,
}

impl ClassObject {
    pub fn new(base:Class) -> Self{
        Self{base}
    }
    pub fn getfield(&self ,n:String) -> Option<Type>{
        self.base.fields.borrow().get(&n).cloned()
    }
    pub fn setfield(&self,n:String,t:Type){
        let mut var = self.base.fields.borrow_mut().get(&n);
        var = Some(&t);
    }
    pub fn getmethod(&self, n:String) -> Option<FUNC>{
        self.base.methods.borrow().get(&n).cloned()
    }
}

// ================= ARRAY TYPE =================

#[derive(Debug, Clone)]
pub struct ArrayType {
    pub name: String,
    pub outFn: fn(&Vec<Type>) -> String,
    pub methods: RefCell<HashMap<String, FUNC>>,
}

impl ArrayType {
    pub fn new(name: String, outFn: fn(&Vec<Type>) -> String) -> Self {
        
        Self { name, outFn, methods: RefCell::new(HashMap::new()) }
    }
    pub fn isinstance(&self, x: &ArrayType) -> bool {
        self.name == x.name
    }
}

#[derive(Debug, Clone)]
pub struct MonoType {
    pub name: String,
    pub outFn: fn(Type) -> String,
    pub methods: RefCell<HashMap<String, FUNC>>,
}

impl MonoType {
    pub fn new(name: String, outFn: fn(Type) -> String) -> Self {
        Self { name, outFn, methods: RefCell::new(HashMap::new()) }
    }
    pub fn isinstance(&self, x: &MonoType) -> bool {
        self.name == x.name
    }
}

// ================= BUFFER TYPE =================
#[derive(Debug, Clone)]
pub struct BufferType {
    pub name: String,
    pub outFn: fn(&Vec<(Type, Type)>) -> String,
    pub methods: RefCell<HashMap<String, FUNC>>,
}

impl BufferType {
    pub fn new(name: String, outFn: fn(&Vec<(Type, Type)>) -> String) -> Self {
        Self { name, outFn, methods: RefCell::new(HashMap::new()) }
    }
    pub fn isinstance(&self, x: &str) -> bool {
        self.name == x
    }
}

// ================= ARRAY =================
#[derive(Debug, Clone)]
pub struct Array {
    pub items: Vec<Type>,
    pub base: ArrayType,
}

impl Array {
    pub fn new(items: Vec<Type>, base: ArrayType) -> Self {
        Self { items, base }
    }
    pub fn runM(&self, func: String, _items: Vec<Type>, base: ArrayType) -> Result<Type, OnfexError> {
        if base.methods.borrow().get(&func).is_some() {
            Ok(Type::newVoid())
        } else {
            Err(OnfexError::Runtime {
                message: format!("undefined method '{}'", func),
            })
        }
    }
}

// ================= BUFFER =================

#[derive(Debug, Clone)]
pub struct Buffer {
    pub mapp: Vec<(Type, Type)>,
    pub base: BufferType,
}

impl Buffer {
    pub fn new(mapp: Vec<(Type, Type)>, base: BufferType) -> Self {
        Self { mapp, base }
    }
}

#[derive(Debug, Clone)]
pub struct Mono {
    pub value: Type,
    pub base: MonoType,
}

impl Mono {
    pub fn new(value:Type, base: MonoType) -> Self {
        Self { value, base }
    }
}

// ================= DEFAULT OUT =================
pub fn default_array_out(v: &Vec<Type>) -> String {
    let mut vals = String::new();
    for i in v {
        vals.push_str(&format!("{}, ", i.__out__()));
    }
    if vals.len() >= 2 {
        vals.truncate(vals.len() - 2);
    }
    format!("[{}]", vals)
}

pub fn default_buffer_out(v: &Vec<(Type, Type)>) -> String {
    let mut vals = String::new();
    for (k, val) in v {
        vals.push_str(&format!("{}:{}, ", k.__out__(), val.__out__()));
    }
    if vals.len() >= 2 {
        vals.truncate(vals.len() - 2);
    }
    format!("{{{}}}", vals)
}
pub fn default_mono_out(v: Type) -> String {
    let mut vals = String::new();
    let res = v.clone().value;
    format!("{:#?}", res)
}

pub fn create_builtins_funcs() -> HashMap<String, FUNC> {
    use crate::builtinsdata::*;
    let mut builtins: HashMap<String, FUNC> = HashMap::new();
    builtins.insert("pyrintnos".to_string(), FUNC { func: pr });
    builtins.insert("morfenlnos".to_string(), FUNC { func: ask });
    builtins
}
