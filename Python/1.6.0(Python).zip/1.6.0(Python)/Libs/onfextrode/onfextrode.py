from dataclasses import dataclass as dc
import sys
sys.path.append("./RealOnfexCompiler/Libs")
from cache.Exceptions import raiseE

class main:
    def __init__(self,node):
        self.version = "0.0.3"
        self.node = node
        self.funcs = {}
        self.vars = {
            "verzen":self.version,
            "fowLt":"\n",
            "seph":" ",
            "onosAsken":"r",
        }
        self.metodes = {}
        self.classes = {}
    
    def __renew__(self):
        self.vars["verzen"] = self.version
        self.vars["fowLt"] = str(self.vars["fowLt"])
        self.vars["seph"] = str(self.vars["seph"])
        if self.vars["onosAsken"] not in ["r","w","a"]:
            self.vars["onosAsken"] = "r"

if __name__ == "__main__":
    pass